# Test for PR#149 -- debugging information left in the code

import java

class Foo(java.io.Serializable):
    def init(self):
        pass
