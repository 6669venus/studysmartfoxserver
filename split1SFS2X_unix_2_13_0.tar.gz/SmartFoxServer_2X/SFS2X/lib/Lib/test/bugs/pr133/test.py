def spam():
    print 'spam'
